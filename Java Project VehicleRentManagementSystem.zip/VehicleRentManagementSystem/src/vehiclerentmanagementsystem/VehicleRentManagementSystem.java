package vehiclerentmanagementsystem;

public class VehicleRentManagementSystem {

    public static void main(String[] args) {
    
    }
    
}
