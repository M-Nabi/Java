package lab6_2;
import java.util.Scanner;
public class Lab6_2 {
 public static void main(String[] args) {

 int std_count=0,faculty_count=0,course_count=0;
 int stopper =0;

 Student[] std_arr = new Student[99999];
 Course[] course_arr = new Course[9999];
 Faculty[] faculty_arr = new Faculty[9999];


 Student std1= new Student(1,"dummy1",4);
 Student std2= new Student(2,"dummy2",4);
 Student std3= new Student(3,"dummy3",4);
 Student std4= new Student(4,"dummy4",4);
 Faculty fac1 = new Faculty(1,"fdummy1","position1");
 Faculty fac2 = new Faculty(2,"fdummy2","position 2");
 Faculty fac3 = new Faculty(3,"fdummy3","position 3");
 Course c1 = new Course( "c1","t1",4.5);
 Course c2 = new Course( "c2","t2",3);
 Course c3 = new Course( "c3","t3",3);
 std_arr[0] = std1;std_count++;
 std_arr[1] = std2;std_count++;
 std_arr[2] = std3;std_count++;
 std_arr[3] = std4;std_count++;
 faculty_arr[0] = fac1;faculty_count++;
 faculty_arr[1] = fac2;faculty_count++;
 faculty_arr[2] = fac3;faculty_count++;
 course_arr[0] = c1;course_count++;
 course_arr[1] = c2;course_count++;
 course_arr[2] = c3;course_count++;

 course_arr[0].addStudent(std1);
 course_arr[0].addStudent(std2);
 course_arr[0].addStudent(std3);
 course_arr[0].addStudent(std4);
 course_arr[0].addFaculty(fac2);

 course_arr[1].addStudent(std1);
 course_arr[1].addStudent(std3);
 course_arr[1].addStudent(std4);
 course_arr[1].addFaculty(fac3);

 course_arr[2].addStudent(std2);
 course_arr[2].addStudent(std4);
 course_arr[2].addFaculty(fac1);

 while(stopper == 0){
 Scanner input = new Scanner(System.in);
 System.out.println("Options : ");
 System.out.println("a. Add");
 System.out.println("b. Delete");
 System.out.println("c. Update");
 System.out.println("d. Print");
 System.out.println("e. Search");
 System.out.println("f. Exit");
 System.out.print("Enter 'a' -'f' :");

 char key = input.next().charAt(0);

 switch(key){



 case 'a':{
 System.out.println("Options :");

 System.out.println("a. Add a student ");
 System.out.println("b. Add a Course ");
 System.out.println("c. Add a Faculty ");

 char key2 = input.next().charAt(0);
 switch(key2){
 case 'a':{

 System.out.println("Enter Student information");
 System.out.print("ID : ");int id = input.nextInt();
 System.out.print("Name : "); String name = input.next();
 System.out.print("CGPA : "); Double CGPA = input.nextDouble();

 std_arr[std_count] = new Student(id,name,CGPA);

 std_count++;


 break;
 }
 case 'b':{

 System.out.println(" Enter Course information ");
 System.out.print("Course Id : ");String courseid= input.next();
 System.out.print("Course Title : ");String coursetitle = input.next();
 System.out.print("Course Credit : ");Double coursecred = input.nextDouble();
 course_arr[course_count] = new Course(courseid,coursetitle,coursecred);

 course_count++;

 break;
 }
 case 'c':{

 System.out.println(" Enter Faculty information ");
 System.out.print("Faculty Id : ");int fac_id = input.nextInt();
 System.out.print("Faculty Name : ");String fac_name = input.next();
 System.out.print("Faculty Position : ");String fac_position = input.next();

 faculty_arr[faculty_count]= new Faculty(fac_id,fac_name,fac_position);

 faculty_count++;

 break;
 }
 }

 break;
 }




 case 'b':{

 System.out.println("Options :");

 System.out.println("a. Delete a student ");
 System.out.println("b. Delete a Course ");
 System.out.println("c. Delete a Faculty ");


 char key2 = input.next().charAt(0);
 switch(key2){
 case 'a':{

 System.out.println(" Enter Student id : ");
 int studentId = input.nextInt();
 int index = -1;;

 for(int i=0;i<std_count;i++){
 if(std_arr[i].getStudentId() == studentId ){
 index = i;

 break;
 }
 }
 if(index == -1){
 System.out.println("Student not found");

 }
 else{
 for(int i=index;i<std_count-1;i++){
 std_arr[i]=std_arr[i+1];
 }
 std_arr[std_count]= null;
 std_count--;

 }
 break;
 }

 case 'b':{

 System.out.println(" Enter Course id : ");
 String studentId = input.next();
 int index = -1;

 for(int i=0;i<course_count;i++){
 if(course_arr[i].getCourseId().equalsIgnoreCase(studentId) ){
 index = i;
 break;

 }
 }
 if(index == -1){
 System.out.println("Course not found");

 }
 else{
 for(int i=index;i<course_count-1;i++){
 course_arr[i]=course_arr[i+1];
 }
 course_arr[course_count]=null;
 course_count--;

 }
 break;
 }
 case 'c':{

 System.out.println(" Enter Faculy id : ");
 int studentId = input.nextInt();
 int index = -1;;

 for(int i=0;i<faculty_count;i++){
 if(faculty_arr[i].getFacultyId() == studentId ){
 index = i;

 }
 }
 if(index == -1){
 System.out.println("Faculty not found");

 }
 else{
 for(int i=index;i<faculty_count-1;i++){
 faculty_arr[i]=faculty_arr[i+1];
 }
 faculty_arr[faculty_count] = null;
 faculty_count--;

 }

 break;
 }
 }
 break;
 }





 case 'c':{


 System.out.println("Options :");

 System.out.println("a. Update any student information ");
 System.out.println("b. Update any Course information");
 System.out.println("c. Update any Faculty information");




 char key2 = input.next().charAt(0);

 switch(key2){
 case 'a':{

 System.out.println(" Enter Student id : ");
 int studentId = input.nextInt();


 for(int i=0;i<std_count;i++){
 if(std_arr[i].getStudentId() == studentId ){

 System.out.println("Enter updated info");
 System.out.print("ID : ");int id = input.nextInt();
 System.out.print("Name : "); String name = input.next();
 System.out.print("CGPA : "); Double CGPA = input.nextDouble();
 std_arr[i].setStudentId(id);
 std_arr[i].setStudentName(name);
 std_arr[i].setCGPA(CGPA);
 break;
 }
 }


 break;
 }

 case 'b':{

 System.out.println(" Enter the Course id of the course you want to update : ");
String studentId = input.next();// Course id
 System.out.println("Press 1 to add or drop students and faculty and any other integer to change information ");


 int a=input.nextInt();
 if(a == 1){
 int index = -1;
 for(int i=0;i<course_count;i++){
 if(course_arr[i].getCourseId().equalsIgnoreCase(studentId) ){
 index = i;break;
 }
 }
 int stopthisloop = -1;
 while(stopthisloop == -1){

 System.out.println("a. add a student");
 System.out.println("b. add a faculty");
 System.out.println("c. drop a student");
 System.out.println("d. drop faculty");
 System.out.println("e. exit");

 char update = input.next().charAt(0);
 switch(update){
 case 'a':{
 System.out.println("Enter student id");
 int studentid = input.nextInt();
 for(int i=0;i<std_count;i++){
 if(std_arr[i].getStudentId() == studentid){

 course_arr[index].addStudent(std_arr[i]);
 break;

 }
 }
 break;
 }
 case 'b':{
 System.out.println("Enter faculty id");
 int studentid = input.nextInt();
 for(int i=0;i<faculty_count;i++){
 if(faculty_arr[i].getFacultyId() == studentid){
 course_arr[index].addFaculty(faculty_arr[i]);
 break;
 }
 }
 break;
 }
 case 'c':{

 System.out.println("Enter student id");
 int studentid = input.nextInt();
 for(int i=0;i<std_count;i++){
 if(std_arr[i].getStudentId() == studentid){

 course_arr[index].dropStudent(studentid);
 break;

 }
 }
 break;
 }
 case 'd':{

 course_arr[index].dropFaculty();

 break;

 }
 case 'e': stopthisloop = 0;
 break;

 }
 }

 }
 else{



 for(int i=0;i<course_count;i++){
 if(course_arr[i].getCourseId().equalsIgnoreCase(studentId) ){
 System.out.println(" Enter Updated Course information ");
 System.out.print("Course Id : ");String courseid= input.next();
 System.out.print("Course Title : ");String coursetitle = input.next();
 System.out.print("Course Credit : ");Double coursecred = input.nextDouble();
 course_arr[i].setCourseId(courseid);
 course_arr[i].setCourseTitle(coursetitle);
 course_arr[i].setCredit(coursecred);
 break;
 }
 }
 }
 break;
 }
 case 'c':{

 System.out.println(" Enter Faculty id : ");
 int studentId = input.nextInt();

 for(int i=0;i<faculty_count;i++){
 if(faculty_arr[i].getFacultyId() == studentId ){

 System.out.println("Enter updated info");
 System.out.print("ID : ");int id = input.nextInt();
 System.out.print("Name: "); String name = input.next();
 System.out.print("Position : "); String position = input.next();
 faculty_arr[i].setFacultyId(id);
 faculty_arr[i].setFacultyName(name);
 faculty_arr[i].setFacultyPosition(position);
 break;
 }
 }

 break;
 }
 }
 break;
 }



 case 'd':{

 System.out.println("Options :");

 System.out.println("a. Print all students ");
 System.out.println("b. Print all courses");
 System.out.println("c. Print all faculties");
 System.out.println("d. Print information of a Student");
 System.out.println("e. Print information of a course");
 System.out.println("f. Print information of a faculty");
 System.out.println("g. Print student list and faculty information of a course");
 System.out.println("h. Print courses taken by a student");

 char key2 = input.next().charAt(0);
 switch(key2){
 case 'a':{

 System.out.println("All student names: ");
 for (int i=0;i<std_count;i++){
 System.out.println("Student "+(i+1)+" : " + std_arr[i].getStudentName());
 }

 break;
 }
 case 'b':{
 System.out.println("All course names: ");
 for (int i=0;i<course_count;i++){
 System.out.println(+(i+1)+". Course Name: " +course_arr[i].getCourseTitle()
+ "Course id : "+course_arr[i].getCourseId());
 }

 break;
 }
 case 'c':{
 for (int i=0;i<faculty_count;i++){
 System.out.println("All faculty names: ");
 System.out.println(+(i+1)+". Faculty Name: "
+faculty_arr[i].getFacultyName());
 }

 break;
 }
 case 'd':{

 System.out.print(" Enter student id :");
 int search = input.nextInt();

 for(int i =0;i<std_count;i++){
 if(search == std_arr[i].getStudentId()){
 System.out.println(std_arr[i].toString());
 }
 }

 break;
 }
 case 'e':{

 System.out.print(" Enter Course id :");
 String search = input.next();

 for(int i =0;i<course_count;i++){
 if(search.equalsIgnoreCase(course_arr[i].getCourseId())){
 System.out.println(course_arr[i].toString());
 }
 }

 break;
 }
 case 'f':{

 System.out.print(" Enter faculty id :");
 int search = input.nextInt();

 for(int i =0;i<faculty_count;i++){
 if(search == faculty_arr[i].getFacultyId()){
 System.out.println(faculty_arr[i].toString());
 }
 }

 break;
 }
 case 'g':{

 System.out.print(" Enter course id : ");
 String search = input.next();
 for(int i=0;i<course_count;i++){
 if((course_arr[i].getCourseId()).equalsIgnoreCase(search)){
 System.out.println("Factulty Info: "+course_arr[i].getFaculty());
 System.out.println("The student list: ");
 course_arr[i].printStudentList();
 break;
 }

 }


 break;
 }
 case 'h':{

 System.out.print("Enter Student id : ");
 int search = input.nextInt(),flag = -1;
 System.out.println("Courses taken by this student are: ");
 for(int i=0;i<course_count;i++){
 for(int j=0;j<course_arr[i].getNumberOfStudents();j++){

 if(search == course_arr[i].getStudentId(j)){
 System.out.println(course_arr[i]);
 flag++;
 break;
 }
 }
 }
 if(flag == -1){
 System.out.println("Student has not taken any courses");
 }

 break;
 }
 }
 break;
 }


 case 'e':{

 System.out.println("Options :");

 System.out.println("a. Search a Student");
 System.out.println("b. Search a Course");
 System.out.println("c. Search a Faculy");
 System.out.println("d. Search if a Student takes a Course");
 System.out.println("e. Search if a Faculty teaches a Course ");
 System.out.println("f. Search Courses taken by a Student ");
 System.out.println("g. Search Courses taught by a Faculty ");


 char key2 = input.next().charAt(0);
 switch(key2){
 case 'a':{ //
 System.out.println("Press 1 to search by name and 2 to search by id");
 int search_option = input.nextInt();
 if(search_option == 1){

 System.out.print("Enter Student name");
 String name = input.next();
 for(int i=0;i<std_count;i++){
 if((std_arr[i].getStudentName()).contains(name)){
 System.out.println();
 System.out.print("Student found, "+std_arr[i].toString());
 }
 }

 }
 else if(search_option == 2){
 // SEARCH BY ID
 System.out.print("Enter Student id");
 int id = input.nextInt();
 for(int i=0;i<std_count;i++){
 if((std_arr[i].getStudentId()) == id){
 System.out.println();
 System.out.print("Student found, "+std_arr[i].toString());
 }
 }

 }


 break;
 }
 case 'b':{ //
 System.out.println("Press 1 to Search by name and 2 to search by id");


 break;
 }
 case 'c':{ //
 System.out.println("Press 1 to search by name and 2 to search by id");
 int search_option = input.nextInt();
 if(search_option == 1){

 System.out.print("Enter Faculty name");
 String name = input.next();
 for(int i=0;i<faculty_count;i++){
 if((faculty_arr[i].getFacultyName()).contains(name)){
 System.out.println();
 System.out.print("Faculty found, "+faculty_arr[i].toString());
 }
 }

 }
 else if(search_option == 2){

 System.out.print("Enter Faculty id");
 int id = input.nextInt();
 for(int i=0;i<faculty_count;i++){
 if((faculty_arr[i].getFacultyId()) == id){
 System.out.println();
 System.out.print("Faculty found, "+faculty_arr[i].toString());
 }
 }

 }
 break;
 }
 case 'd':{
 System.out.println("Enter Student id : ");int std_mame= input.nextInt();
 System.out.println("Enter course id : ");String courseid = input.next();
 int index = -1,index2=-1;
 for(int i=0;i<course_count;i++){
 if(courseid.equalsIgnoreCase(course_arr[i].getCourseId())){
 index = i;
 }
 }
 if(index != -1){
 for(int i =0; i<course_arr[index].getNumberOfStudents();i++){
 if(course_arr[index].getStudentId(i) == std_mame){
 index2 ++;
 }
 }

 }
 else{
 System.out.println("Course not Found");
 }

 if(index2 == -1){
 System.out.println("Studnet has not taken the course");
 }
 else{
 System.out.println("Student has taken the course");
 }

 break;

 }
 case 'e':{
 System.out.println("Enter Faculty id : ");int std_mame= input.nextInt();
 System.out.println("Enter course id : ");String courseid = input.next();
 int index = -1,index2=-1;
 for(int i=0;i<course_count;i++){
 if(courseid.equalsIgnoreCase(course_arr[i].getCourseId())){
 index = i;
 }
 }
 if(index != -1){

 if(course_arr[index].getFacultyId() == std_mame){
 index2 ++;
 }


 }
 else{
 System.out.println("Course not Found");
 }


 if(index2 == -1){
 System.out.println("Faculty takes the course");
 }
 else{
 System.out.println("Faculty does not taken the course");
 }


 break;

 }
 case 'f':{
 System.out.println("Enter Stundent id : ");int std_mame= input.nextInt();

 System.out.println("Courses taken by this student are: ");
 int index = -1;
 for(int i=0;i<course_count;i++){
 for(int j=0;j<course_arr[i].getNumberOfStudents();j++){

 if(course_arr[i].getStudentId(j) == std_mame){
 System.out.println(course_arr[i].toString());index++;

 index ++;

 }
 }
 }
 System.out.println("Total "+(index+1)+" courses");
 if(index == -1){
 System.out.println("Student has not taken any courses ");
 }
 break;

 }
 case 'g':{
 System.out.println("Enter Faculty id : ");int std_mame= input.nextInt();

 System.out.println("Courses taken by this faculty are: ");
 int index = -1;
 for(int i=0;i<course_count;i++){


 if(course_arr[i].getFacultyId() == std_mame){
 System.out.println(course_arr[i].toString());index++;

 index ++;

 }

 }
 System.out.println("Total "+(index+1)+" courses");
 if(index == -1){
 System.out.println("Student has not taken any courses ");
 }

 break;

 }

 }
 break;
 }

 case'f':{
 stopper =1;
 break;
 }
 default :{

 }
 break;
 }
 }
 }
 }
class Student{
 public int getStudentId() {
 return studentId;
 }
 public void setStudentId(int studentId) {
 this.studentId = studentId;
 }
 public String getStudentName() {
 return studentName;
 }
 public void setStudentName(String studentName) {
 this.studentName = studentName;
 }
 public double getCGPA() {
 return CGPA;
 }
 public void setCGPA(double CGPA) {
 this.CGPA = CGPA;
 }

 private int studentId;
 private String studentName;
 private double CGPA;
 public Student(){

 }
 public Student(int studentId,String studentName,double studentCGPA){

 this.studentId = studentId;
 this.studentName = studentName;
 this.CGPA = studentCGPA;
 }
 @Override
 public String toString(){

 return "Id: "+studentId+ "Name: "+studentName+ "CGPA: "+CGPA;
 }



}
class Course{


 public String getCourseId() {
 return courseId;
 }
 public void setCourseId(String courseId) {
 this.courseId = courseId;
 }
 public String getCourseTitle() {
 return courseTitle;
 }
 public void setCourseTitle(String courseTitle) {
 this.courseTitle = courseTitle;
 }
 public double getCredit() {
 return credit;
 }
 public void setCredit(double credit) {
 this.credit = credit;
 }
 public Student[] getStudentlist() {
 return studentlist;
 }
 public void setStudentlist(Student[] studentlist) {
 this.studentlist = studentlist;
 }
 public int getNumberOfStudents() {
 return numberOfStudents;
 }
 public void setNumberOfStudents(int numberOfStudents) {
 this.numberOfStudents = numberOfStudents;
 }
 public Faculty getFaculty() {
 return faculty;
 }
 public void setFaculty(Faculty faculty) {
 this.faculty = faculty;
 }
 public static int getStudent_counter() {
 return student_counter;
 }
 public static void setStudent_counter(int student_counter) {
 Course.student_counter = student_counter;
 }
 public int getStudentId(int n){
 return studentlist[n].getStudentId();
 }
 public int getFacultyId(){
 return faculty.getFacultyId();
 }
 @Override
 public String toString() {
 return "Course{" + "courseId=" + courseId + ", courseTitle=" + courseTitle + ", credit=" +
credit + ", numberOfStudents=" + numberOfStudents + ", faculty=" + faculty + '}';
 }

 private String courseId;
 private String courseTitle;
 private double credit;
 private Student[] studentlist = new Student[40];
 private int numberOfStudents =-1;
 private Faculty faculty;
 static int student_counter =0;

 public Course(){
 this.numberOfStudents++;
 student_counter++;

 }
 public Course(String courseId,String courseTitle,double credit){
 this.courseId = courseId;
 this.courseTitle = courseTitle;
 this.credit = credit;
 this.numberOfStudents++;
 student_counter++;
 }


 public void addStudent(Student std){

 this.studentlist[numberOfStudents] = std;
 student_counter++;
 numberOfStudents++;

 }



 public void dropStudent(int studentId){

 int index = -1;
 for(int i=0;i<numberOfStudents;i++){
 if(studentlist[i].getStudentId() == studentId ){
 index = i;

 break;

 }
 }
 if(index == -1){
 System.out.println("Student not found");
 }
 else{
 for(int i=index;i<numberOfStudents-1;i++){

 studentlist[i]=studentlist[i+1];
 }
 studentlist[numberOfStudents] = null;
 numberOfStudents--;
 }

 }
 public void addFaculty(Faculty faculty){
 this.faculty = faculty;
 }
 public void dropFaculty(){
 this.faculty = null;
 }
 public void printStudentList(){
 System.out.println(numberOfStudents);
 for(int i=0;i<numberOfStudents;i++){
 System.out.println(studentlist[i].toString());
 }
 }
}
class Faculty{
 @Override
 public String toString() {
   return "Faculty{" + "facultyId=" + facultyId + ", facultyName=" + facultyName + ", facultyPosition=" + facultyPosition + '}';
  }
 public int getFacultyId() {
 return facultyId;
 }
 public void setFacultyId(int facultyId) {
 this.facultyId = facultyId;
 }
 public String getFacultyName() {
 return facultyName;
 }
 public void setFacultyName(String facultyName) {
 this.facultyName = facultyName;
 }
 public String getFacultyPosition() {
 return facultyPosition;
 }
 public void setFacultyPosition(String facultyPosition) {
 this.facultyPosition = facultyPosition;
 }

 private int facultyId;
 private String facultyName;
 private String facultyPosition;

 public Faculty(){

 }
 public Faculty(int facultyId, String facultyName,String facultyPosition){
 this.facultyId = facultyId;
 this.facultyName = facultyName;
 this.facultyPosition = facultyPosition;

 }
}