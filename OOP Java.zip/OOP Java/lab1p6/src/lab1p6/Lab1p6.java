
package lab1p6;

import java.util.Scanner;

public class Lab1p6 {

         static int prime_checker(int x)
{
    int i=2,flag = 0;
    if (x <=0 || x == 1 )
    {
        
        return 0;
    }
    else
    {
        
        for(i=2;i<=x/2;i++)
        {
            if (x%i == 0)
            {
               
                flag++;
                break;
            }
        }
        if (flag == 0)
        {
            return 1;
        }
        else
            return 0;
    }
}
   
    public static void main(String[] args) {
        
        
        int x;
   
   System.out.println(" Input a number to see how many non primes there are upto that number:");
   Scanner input= new Scanner(System.in);
    int i;
    x=input.nextInt();

    for(i=1;i<=x ; i++)
    {
        
        if(prime_checker(i) == 0)
        {
            System.out.print(i+",");
        }
    }
    }
    
}



   
    