
package lab1p5;

import static java.lang.Math.pow;
import java.util.Scanner;

public class Lab1p5 {

    public static void main(String[] args) {
        System.out.println("Enter a number ");
       Scanner input = new Scanner(System.in);
       int a = input.nextInt();
       int b=a,c=a;
       int sum=0;
       int digit=0;
       while(b>0)
       {
           b=b/10;
           digit++;
       }
       b=a;
       
       while(b>0)
       {
           b=a%10;
           a=a/10;
           sum=(int) (sum+pow(b,digit));
       }
      System.out.println("The armstrong number is  " +sum);
      if (c == sum )
      {
          System.out.println("The number is armstrong");
      }
      else
      {
          System.out.println("The number is not armstrong");
       
      }   
    }
}
