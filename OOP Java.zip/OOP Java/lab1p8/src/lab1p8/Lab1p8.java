
package lab1p8;

import java.util.Scanner;

public class Lab1p8 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
       System.out.println("Enter The Value of A:");
       int a = input.nextInt();
       System.out.println("Enter The value of B:");
       int b = input.nextInt();
       a = a+b;
       b = a-b;
       a = a-b;
       System.out.println("The value of A is "+a+" The value of B is " +b);
   
    }
    
}
