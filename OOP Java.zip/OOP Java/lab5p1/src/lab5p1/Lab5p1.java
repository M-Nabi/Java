
package lab5p1;

import java.util.Scanner;

public class Lab5p1 {
    static String searchByCompany(String Search_Key,Icecream object){
        
       if((object.getIcecreamCompany()).equalsIgnoreCase(Search_Key)){
        return object.dataToOneString();
    }
       else{
           return "";
       }  
    }
 

    public static void main(String[] args) {
        
       Scanner input = new Scanner(System.in);
        System.out.print("Enter how many elements you want in the array? : ");
       int n= input.nextInt();
   
        Icecream[] IcecreamArray = new Icecream[n];
        String type,company;
        double price;
       
        
        for(int i=0;i<n;i++){
            
            System.out.print("Enter Icecream["+i+"] type: ");type=input.next();
            System.out.print("Enter Icecream["+i+"] company: ");company=input.next();
            System.out.print("Enter Icecream["+i+"] price: ");price=input.nextDouble();
            IcecreamArray[i] = new Icecream(type,company,price);
           }
       
        System.out.println("Printing all the data: ");
        for(int i=0;i<n;i++){
            System.out.println(IcecreamArray[i].dataToOneString());
        }
        
        System.out.print("Enter Company name you want to search : ");
        String Search_Key = input.next();
      
        for( int i=0;i<n;i++){
            System.out.print(searchByCompany(Search_Key,IcecreamArray[i]));
        }
    }

}
class Icecream{

    public String getIcecreamType() {
        return icecreamType;
    }

    public void setIcecreamType(String icecreamType) {
        this.icecreamType = icecreamType;
    }

    public String getIcecreamCompany() {
        return icecreamCompany;
    }

    public void setIcecreamCompany(String icecreamCompany) {
        this.icecreamCompany = icecreamCompany;
    }

    public double getIcecreamPrice() {
        return icecreamPrice;
    }

    
    public void setIcecreamPrice(double icecreamPrice) {
        this.icecreamPrice = icecreamPrice;
    }
        private String icecreamType;
        private String icecreamCompany;
        private double icecreamPrice;

        Icecream(){
           
        }
        
        Icecream(String icecreamType,String icecreamCompany,double icecreamPrice){
            this.icecreamType = icecreamType;
            this.icecreamCompany = icecreamCompany;
            this.icecreamPrice = icecreamPrice;
    
        }
        
       public String dataToOneString(){

           String data = icecreamType+" "+" ";
            data += icecreamCompany+" "+" ";
            data += icecreamPrice+" "+"\n";
            return data;
        }
        
        public boolean equalPrice(Icecream icecreamPrice){
            
        return this.icecreamPrice == icecreamPrice.icecreamPrice;
        }
        public int comparePrice(Icecream price){
            
            if(this.icecreamPrice > price.icecreamPrice){
                return 1;
            }
            else if(this.icecreamPrice == price.icecreamPrice){
                return 0;
            }
            else {
                return -1;
            }
        }
      
}

