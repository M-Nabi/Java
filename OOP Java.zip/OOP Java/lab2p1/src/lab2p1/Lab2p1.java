
package lab2p1;

import java.util.Scanner;

public class Lab2p1 {

    public static void main(String[] args) {
                System.out.println("Input the radius:");
        Scanner input= new Scanner(System.in);
        float r;
        r = input.nextFloat();
        float pi = (float) 3.1416;
        
        System.out.println("The perimeter is "+2*pi*r);
        System.out.println("The Area is "+pi*r*r);
        
    }
    
}
