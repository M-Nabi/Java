
package lab5p3;

import java.util.Scanner;

public class Lab5p3 {

    public static void main(String[] args) {
 
        Scanner input = new Scanner(System.in);
        System.out.print("Input the first fraction , a.");
        Fraction a = new Fraction();
        System.out.print("Enter numerator of a : ");
        int nume1 = input.nextInt();
        System.out.print("Enter denominator of a: ");
        int denom1 = input.nextInt();
        a.setNumerator(nume1);
        a.setDenominator(denom1);

        System.out.print("Input the first fraction , b.");
        System.out.print("Enter numerator of b : ");
        int nume2 = input.nextInt();
        System.out.print("Enter denominator of b : ");
        int denom2 = input.nextInt();
        Fraction b = new Fraction(nume2, denom2);
        
        System.out.println("The first fraction is : "+a.tostring());
        System.out.println("The seconf fraction is : "+b.tostring());
        
        System.out.println("calculation test, a+b , a-b , a*b , a/b :");

        a.add(b); 
        System.out.println("The sum is :"+a.tostring());
         a.setNumerator(nume1);
        a.setDenominator(denom1);
        
        
        a.sub(b); 
        a.tostring();
         System.out.println("The substraction is :"+a.tostring());
         a.setNumerator(nume1);
        a.setDenominator(denom1);
        
        a.multiplication(b);
        a.tostring();
         System.out.println("The multiplication is :"+a.tostring());
         a.setNumerator(nume1);
        a.setDenominator(denom1);
        
        
        a.division(b);
        a.tostring();
         System.out.println("The division is :"+a.tostring());
         a.setNumerator(nume1);
        a.setDenominator(denom1);

    }
}
class Fraction {

    private int numerator;
    private int denominator;

    Fraction() {

    }

    public Fraction(int numerator, int denominator) {
        this.denominator = denominator;
        this.numerator = numerator;
    }

    public int getDenominator() {
        return this.denominator;
    }

    public int getNumereator() {
        return this.numerator;
    }

    public void setDenominator(int denominator) {
        this.denominator = denominator;
    }

    public void setNumerator(int numerator) {
        this.numerator = numerator;
    }

    public String tostring() {
        String data = Integer.toString(this.numerator);
        data += "/" + Integer.toString(this.denominator) + " ";

        return data;
    }

    public void add(Fraction fraction) {

        String newNumerator, newDenominator;
        newNumerator = Integer.toString(this.numerator * fraction.denominator + this.denominator * fraction.numerator);
        newDenominator = Integer.toString(fraction.denominator * this.denominator);

         this.numerator = this.numerator * fraction.denominator + this.denominator * fraction.numerator;
         this.denominator = fraction.denominator * this.denominator;
    }

    public void sub(Fraction fraction) {

        String newNumerator, newDenominator;
        newNumerator = Integer.toString(this.denominator * fraction.numerator - this.numerator * fraction.denominator);
        newDenominator = Integer.toString(fraction.denominator * this.denominator);

        this.numerator =this.denominator * fraction.numerator - this.numerator * fraction.denominator;
        this.denominator = fraction.denominator * this.denominator;
    }

    public void multiplication(Fraction fraction) {

        String newNumerator, newDenominator;
        newNumerator = Integer.toString(this.numerator * fraction.numerator);
        newDenominator = Integer.toString(fraction.denominator * this.denominator);

        this.numerator = this.numerator * fraction.numerator;
        this.denominator = fraction.denominator * this.denominator;
    }

    public void division(Fraction fraction) {

        String newNumerator, newDenominator;
        newNumerator = Integer.toString(this.numerator * fraction.denominator);
        newDenominator = Integer.toString(fraction.numerator * this.denominator);

        this.numerator = this.numerator * fraction.denominator ;
        this.denominator = fraction.numerator * this.denominator;
    }

}
