
package lab2p5;

import java.util.Scanner;

public class Lab2p5 {

    public static void main(String[] args) {
       Scanner input= new Scanner(System.in);
        System.out.println(" Enter the center's xand and y axes and radius of the circle ");
        
        System.out.println("p= ");float p=input.nextFloat();
        System.out.println("q = ");float q=input.nextFloat();
        System.out.println("r = ");float r=input.nextFloat();
       
        System.out.println(" Enter any point's x and y values ");
        
        System.out.println("x= ");float x=input.nextFloat();
        System.out.println("y = ");float y=input.nextFloat();
        
      float radius2=(float) Math.sqrt((x-p)*(x-p) + (y-q)*(y-q));
      if(r>=radius2)
      {
          System.out.println("Inside the circle");
      }
      else if(r<radius2)
      {
          System.out.println("Outside the Circle");
      }
        
    }
    
}