package lab2p2;

import java.util.Scanner;

public class Lab2p2 {

    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        int x= input.nextInt();
        System.out.println("ENTER A NUMBER:");
        
        if(x%6 == 0)
        {
            System.out.println("FALSE");
        }
        else if(x%2 == 0 || x%3 == 0)
        {
            System.out.println("TRUE");
        }
        else 
        {
            System.out.println("FALSE");
        }
    }
    
}