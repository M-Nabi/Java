
package lab2p3;

import java.util.Scanner;

public class Lab2p3 {

    public static void main(String[] args) {
        System.out.println(" Enter the number of minutes");
        Scanner input = new Scanner(System.in);
       
        long min=input.nextInt();
        long year=0 ,day =0,dummy=min;
        
        
        if(dummy>(60*24*365) )
        {
            year= dummy/(60*24*365);
            dummy = dummy%(60*24*365);
            
        }
        if (dummy>(60*24))
        {
            day = dummy/(60*24);
            dummy = dummy%(60*24);
        }
        System.out.println(min+ "minutes is approximately "+year+" years and " +day+ " days ");
        
            
        
        
    }
    
}
