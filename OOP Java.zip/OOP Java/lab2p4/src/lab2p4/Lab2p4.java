
package lab2p4;

import java.util.Scanner;

public class Lab2p4 {

    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        System.out.println(" Enter a,b,c ");
        
        System.out.println("a = ");float a=input.nextFloat();
        System.out.println("b = ");float b=input.nextFloat();
        System.out.println("c = ");float c=input.nextFloat();
        
        if(b*b - 4*a*c > 0)
        {
        
        float root1=  (float) (-1*b + Math.sqrt(b*b - 4*a*c))/(2*a);
        float root2=  (float) (-1*b - Math.sqrt(b*b - 4*a*c))/(2*a);
        
        System.out.println("The equation has two real solutions, "+root1+ " and "+root2);
        
        }
        else if (b*b - 4*a*c == 0)
        {
            float root3= (-1*b)/(2*a);
            System.out.println(" The Equation only has one real solution, "+root3);
        }
        
        else
        {
            System.out.println("The equation has no real roots");
        }
  
    }
}
