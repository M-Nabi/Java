
package lab1p7;

import java.util.Scanner;

public class Lab1p7 {

    public static void main(String[] args) {
                Scanner input = new Scanner(System.in);
       System.out.println("Enter Width=");
       float w = input.nextFloat();
       System.out.println("Enter Height=");
       float h = input.nextFloat();
        
        float a= h*w;
        float p=2*(w+h);
        System.out.println("The Area is " +a+ " and the Parameter is " +p);
        
    }
    
}