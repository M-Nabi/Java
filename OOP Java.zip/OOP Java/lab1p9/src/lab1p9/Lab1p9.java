package lab1p9;

import java.util.Scanner;

public class Lab1p9 {

    public static void main(String[] args) {
       System.out.println("Enter a number:");
       Scanner input = new Scanner(System.in);
       int a = input.nextInt();
      
       int b=0;
       if(a <0)
       {
           a= a*-1;
       }
       while(a > 0)
       {
           b=b*10+a%10;
           a=a/10;
           
       }
         System.out.println("The reverse of the number is  "+b);
       
    }
    
}