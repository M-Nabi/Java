
package lab5p2;

import java.util.Scanner;

public class Lab5p2 {

    public static void main(String[] args) {
       
        Scanner input = new Scanner(System.in);

       int isbn,pagenumber;
       String title;
       Book[] arr = new Book[5];
        for(int i=0;i<5;i++){
            System.out.println("Input the values of book ["+(i+1)+"]");
            System.out.print("Enter ISBN :");isbn = input.nextInt();
             System.out.print("Enter Title :");title = input.next();
              System.out.print("Enter Number of Pages:");pagenumber = input.nextInt();
            arr[i] = new Book(isbn,title,pagenumber);   
        }   
        
       for(int i=0;i<5;i++){ 
           System.out.println("Book ["+i+1+"] data"+arr[i].tostring());
       }
        System.out.println("compareTo() test(sample used:book 2 and 3): "+arr[1].compareTo(arr[2]));
        System.out.println("getCount() test: "+Book.getCount());
        System.out.println("getNumberOfPages test(sample used:book 3): "+arr[2].getNumberOfPages());
        System.out.println("isHeavier() test(test sample: book3) :"+isHeavier(arr[2]));
       
       
       
    }
    static boolean isHeavier(Book object){
        return object.getNumberOfPages() > 500;
    }
}
class Book{
    private int ISBN;
    private String bookTitle;
    private int numberOfPages;
    private static int count=0;
    
    public Book(int ISBN,String bookTitle,int numberOfPages){
        this.ISBN = ISBN;
        this.bookTitle = bookTitle;
        this.numberOfPages = numberOfPages;
        count++;
    }
    
    public Book(){
        count++; 
    }
    
    public String tostring(){
        
        String data = "ISBN : "+Integer.toString(this.ISBN)+"\n";
        data += "Book Title : "+ this.bookTitle + "\n";
        data += "Number of Pages : "+ Integer.toString(this.numberOfPages)+"\n";
        
        return data;
    }
    
    public int compareTo(Book object){
        if(object.numberOfPages > this.numberOfPages){
            return 1;
        }
        else if(object.numberOfPages == this.numberOfPages){
            return 0;
        }
        else{
            return -1;
        }
    }
 
    public int getISBN(){
        return ISBN;
    }
    public String getBookTitle(){
        return bookTitle;
    }
    public int getNumberOfPages(){
        return numberOfPages;
    }
    public static int getCount(){
        return count;
    }
 
    public void setISBN(int ISBN){
        this.ISBN = ISBN;
    }
    public void  setBookTitle(String bookTitle){
        this.bookTitle = bookTitle;
    }
    public void  setNumberOfPages(int numberOfPages){
        this.numberOfPages = numberOfPages;
    }
    public static void  setCount(int count){
        Book.count = count;
    }
    
}

