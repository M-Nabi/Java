package lab1.p4;

import java.util.Scanner;

public class Lab1P4 {

    public static void main(String[] args) {
        System.out.println("Enter a number to get its factorial:");
        Scanner input = new Scanner(System.in);
        int a = input.nextInt();
        int factorial =1, b=a;
        while(a != 1)
        {
            factorial=factorial * a;
            a= a-1;
        }
        System.out.println("The Factorial of "+b+" is "+factorial);
    }
    
}
