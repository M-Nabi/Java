package lab7.a.b.c;

import java.util.ArrayList;
import java.util.Scanner;

public class Lab7ABC {

    public static void main(String[] args) {
                  Scanner input = new Scanner (System.in);
        
       
        ArrayList<Account> account_arr = new ArrayList<>();
//// TEST DATA START 
        account_arr.add(0, new Checking(1122,15000,4.5,2000));
        account_arr.add(1, new Savings(7645,500000,1.2,"1234567890"));
        account_arr.add(2, new Savings(3389,200350,2.1,"9876543210"));
        account_arr.add(3, new Checking(1246,65720,4.0,500));
//// TEST DATA END        
        int stopper =0;
        int counter =0;
        
       System.out.println("Entering loop 1");
        while(stopper == 0){
            
            
            System.out.println("Index number : "+counter);
            System.out.println(" Press (1) for creating a Checking Account\n"
                            + " Press (2) for creating a Savings Account\n"
                            + " Press(-1) to Exit");
            System.out.print("Input : ");
            int type = input.nextInt();
        if(type == 1){ // INPUT CHECKING  
            System.out.println("Enter info for the checking account");
            System.out.print("Enter account id : ");int id = input.nextInt();
            System.out.print("Enter Balance : ");double balance= input.nextDouble();
            System.out.print("Enter Annual Interest Rate : ");double rate= input.nextDouble();
            System.out.print("Enter Overdraft limit : ");double overdraft = input.nextDouble();
            
            account_arr.add(counter,new Checking(id,balance,rate,overdraft));
            System.out.println("Operation Successful\n");
            counter++;
        }
        
        else if(type == 2 ){ // INPUT SAVINGS
            System.out.println("Enter info for the savings account");
            System.out.print("Enter account id : ");int id = input.nextInt();
            System.out.print("Enter Balance : ");double balance= input.nextDouble();
            System.out.print("Enter Annual Interest Rate : ");double rate= input.nextDouble();
            System.out.print("Enter Credit Card ID : ");String overdraft = input.next();
            
            account_arr.add(counter,new Savings(id,balance,rate,overdraft));
            System.out.println("Operation Successful\n");
            counter++;
        }
        else if( type == -1){
            System.out.println("Exiting  loop 1");
            stopper = -1;
        }
        }
        
        System.out.println("Entering loop 2");
        while(stopper < 0){ // Withdraw/ Deposit
            
            
            
            System.out.print("Enter index number of the account, enter -1 to exit : ");
            int type = input.nextInt();
            if(type == -1){
                System.out.println("Exiting loop 2");
                stopper = 10;
            }
            else{
                stopper = -2;
                System.out.println("Entering loop 3");
                while(stopper == -2){
                    System.out.println("Account id : "+account_arr.get(type).getId()
                                     + "\nCurrent Balance : "+account_arr.get(type).getBalance()+"\n");
                System.out.println(" Enter (1) to withdraw\n"
                                 + " Enter (2) to deposit\n"
                                 + "Enter -1 to exit ");
                System.out.print("Input : ");
                int type2 = input.nextInt();
                    switch (type2) {
                        case 1: // withdraw
                            {
                                System.out.print(" Enter the amount you want to Withdraw : ");
                                int amount = input.nextInt();
                                if(amount > account_arr.get(type).getBalance()){
                                    System.out.println("Not enough balance");
                                }
                                else{
                                account_arr.get(type).withdraw(amount);}
                              
                                break;
                            }
                        case 2: 
                            {
                                System.out.print(" Enter the amount you want to Deposit : ");
                                int amount = input.nextInt();
                                account_arr.get(type).deposit(amount);
                               
                                break;
                            }
                        case -1: 
                            System.out.println("Exiting loop 3");
                            stopper--;
                            break;
                        default:
                            break;
                    }
               }
            }  
        }
        
        for(int i=0;i<account_arr.size();i++){
            
            if(account_arr.get(i) instanceof Checking){
                
                System.out.println("Index :"+i);
                System.out.println("This is a Checking account");
                Checking dummy = (Checking) account_arr.get(i);
                
                System.out.println("Account id : "+dummy.getId());
                System.out.println("Current Balance : "+dummy.getBalance());
                System.out.println("Annual Interest Rate : "+dummy.getAnnualInterestRate()+"%");
                System.out.println("Monthly Interest Amount : "+dummy.getMonthlyInterestAmount()+"");
                System.out.println("Overdraft Limit : "+dummy.getOverdraft()+"\n");

              
            }
            else if(account_arr.get(i) instanceof Savings){
                
               // +account_arr.get(i)
                System.out.println("Index :"+i);
               System.out.println("This is a Savings account");
               
               Savings dummy = (Savings) account_arr.get(i);
               
               System.out.println("Account id : "+dummy.getId());
               System.out.println("Current Balance : "+dummy.getBalance());
               System.out.println("Annual Interest Rate : "+dummy.getAnnualInterestRate()+"%");
               System.out.println("Monthly Interest Amount : "+dummy.getMonthlyInterestAmount()+"");
               System.out.println("Credit Card Number : "+dummy.getCreditCardId());
               System.out.println("Credit Balance : "+dummy.getCreditBalance()+"\n");
               
             
            }
        }
    }
}

class Account{

    @Override
    public String toString() {
        return "Account{" + "id=" + id + ", balance=" + balance + ", annualInterestRate=" + annualInterestRate + '}';
    }
    
    private int id=0;
    private double balance=0.0;
    private double annualInterestRate=0.0;
    
    Account(){
    }
    
    Account(int id,double balance,double annualInterestRate){
        this.id = id;
        this.balance = balance;
        this.annualInterestRate = annualInterestRate;
    }
     public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public double getBalance() {
        return balance;
    }
    public void setBalance(double balance) {
        this.balance = balance;
    }
    public double getAnnualInterestRate() {
        return annualInterestRate;
    }
    public void setAnnualInterestRate(double annualInterestRate) {
        this.annualInterestRate = annualInterestRate;
    }
    public double getMonthlyInterestRate(){
     
        return this.annualInterestRate/(12*100);
    }
    public double getMonthlyInterestAmount(){
        return ((this.balance)*(this.getMonthlyInterestRate()) );  
    }
    public void withdraw(double amount){
        if(this.balance < amount){
            System.out.println("This amount is not available in this account");
        }
        else
        this.balance = this.balance - amount;
    }
    public void deposit(double amount){
        this.balance = this.balance + amount;
    }
}

class Checking extends Account{
    double overdraft;
    
    Checking(){}
    Checking(int id,double balance,double annualInterestRate,double overdraft){
        super(id,balance,annualInterestRate);
        this.overdraft = overdraft;
    }
    double getOverdraft(){
        return this.overdraft;
    }
    
    public double getCreditBalance(){
        return 3*this.getBalance();
    } 
}

class Savings extends Account{
    //double overdraft;
    String creditCardId;
    Savings(){}
    Savings(int id,double balance,double annualInterestRate,String creditcard){
        super(id,balance,annualInterestRate);
        this.creditCardId = creditcard;
    }
    public String getCreditCardId(){
        return creditCardId;
    }
    
    public double getCreditBalance(){
        return 3*this.getBalance();
    } 
}
    
